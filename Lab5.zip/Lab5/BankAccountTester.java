public class BankAccountTester
    {
        public static void main(String[] args){
            BankAccount harrysChecking=new BankAccount();
            harrysChecking.deposit(2000);
            harrysChecking.withdrawal(500);
            System.out.println(harrysChecking.GetBalance());
            System.out.println("Expected 1500:");
            BankAccount jacobsChecking=new BankAccount(1200);
            BankAccount tuckersChecking=new BankAccount(600);
            BankAccount melvinsChecking=new BankAccount(420);
            System.out.println("JacobsChecking: " + jacobsChecking.GetBalance());
            System.out.println("TuckersChecking: " + tuckersChecking.GetBalance());
            System.out.println("MelvinsChecking: " + melvinsChecking.GetBalance());
            jacobsChecking.addInterest(.10);
            tuckersChecking.addInterest(.10);
            melvinsChecking.addInterest(.10);
            System.out.println("Jacobs Estimated balance: $1320");
            System.out.println("Tuckers Estimated balance: $660");
            System.out.println("Melvins Estimated balance: $ 462");
            System.out.println("Jacobs balance: " + jacobsChecking.GetBalance());
            System.out.println("Tuckers balance: " + tuckersChecking.GetBalance());
            System.out.println("Melvins balance: " + melvinsChecking.GetBalance());
        }
    }
