public class SalesTax
{
    private double tax;
    public double purchasePrice;
    public double taxDue;
    public double totalCost;
     public SalesTax(){
    
        tax=0;
    }
    public SalesTax(double inputTax){
    
        tax=inputTax;
    }
    public  void calculateSalesTax(double purchase){
    
        purchasePrice = purchase;
        taxDue = purchasePrice * tax;
    }
    public  void totalCost(){
    
        totalCost=purchasePrice+taxDue;
    }
    public double getTotalCost(){
    
        return totalCost;
    }
}
   
    
    
    
        
    
        
    
    
    
        
