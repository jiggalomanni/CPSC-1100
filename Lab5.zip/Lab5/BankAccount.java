public class BankAccount{
        private double balance;
        public BankAccount()
        {
            balance=0;
        }
        public BankAccount(double initialBalance)
        {
            balance=initialBalance;
        }
        public void deposit(double amount){
            balance=balance+amount;
        }
        public void withdrawal(double amount)
        {
            balance=balance-amount;
        }
        public double GetBalance()
        {return balance;

        }
    public void addInterest(double InterestRate){
        balance=balance+(balance*InterestRate);
       
    }
   
    
    
    
}
        
        
      
  