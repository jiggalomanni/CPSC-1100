public class SalesTaxTester
{
    public static void main(String[] args)
    {
        double cost;
        SalesTax Cereal = new SalesTax(.10);
        
        Cereal.calculateSalesTax(3.99);
        Cereal.totalCost();
        cost = Cereal.getTotalCost();
        System.out.print("cost: " + cost);
    }
}
       